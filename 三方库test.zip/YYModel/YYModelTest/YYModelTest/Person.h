//
//  Person.h
//  YYModelTest
//
//  Created by Iris on 2018/4/2.
//  Copyright © 2018年 Iris. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 {
 "name":"Jeff",
 "age":"26",
 "sex":"Man",
 "wifeName":"ZQY"
 }
 */
@interface Person : NSObject
@property NSString *name;
@property NSString *age;
@property NSString *sex;
@property NSString *wifeName;

@end
