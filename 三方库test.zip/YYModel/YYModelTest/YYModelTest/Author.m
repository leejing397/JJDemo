//
//  Author.m
//  YYModelTest
//
//  Created by Iris on 2018/4/2.
//  Copyright © 2018年 Iris. All rights reserved.
//

#import "Author.h"

@implementation Author

@end
