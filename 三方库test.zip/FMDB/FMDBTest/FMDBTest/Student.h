//
//  Student.h
//  FMDBTest
//
//  Created by Iris on 2018/4/10.
//  Copyright © 2018年 Iris. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@property (nonatomic,copy)NSString *name;

@property (nonatomic,copy)NSString *sex;

@property (nonatomic,assign) int age;

@property (nonatomic,assign) int studentID;

@end
