UITableView+FDTemplateLayoutCell
##1.简介

`UITableView+FDTemplateLayoutCell` 是一个由国人团队开发的优化计算 `UITableViewCell`高度的轻量级框架（https://github.com/forkingdog/UITableView-FDTemplateLayoutCell），由于实现逻辑简明清晰，代码也不复杂，非常适合作为新手学习其他著名却庞大的开源项目的“入门教材”。