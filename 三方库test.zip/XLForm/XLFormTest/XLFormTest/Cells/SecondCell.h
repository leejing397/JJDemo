//
//  SecondCell.h
//  XLFormTest
//
//  Created by Iris on 2018/4/8.
//  Copyright © 2018年 Iris. All rights reserved.
//

#import "XLFormBaseCell.h"

extern NSString * const XLFormRowSecondCell;

@interface SecondCell : XLFormBaseCell

@end
