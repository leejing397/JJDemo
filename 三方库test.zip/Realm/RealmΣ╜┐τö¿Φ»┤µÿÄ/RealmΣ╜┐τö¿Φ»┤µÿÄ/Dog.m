//
//  Dog.m
//  Realm使用说明
//
//  Created by Iris on 2018/3/30.
//Copyright © 2018年 Iris. All rights reserved.
//

#import "Dog.h"

@implementation Dog

// Specify default values for properties

//+ (NSDictionary *)defaultPropertyValues
//{
//    return @{};
//}

// Specify properties to ignore (Realm won't persist these)

//+ (NSArray *)ignoredProperties
//{
//    return @[];
//}

@end
